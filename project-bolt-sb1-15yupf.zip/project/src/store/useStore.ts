import { create } from 'zustand';
import type { Appointment, Medicine, Exercise, PatientProfile } from '../types';

interface Store {
  profile: PatientProfile | null;
  appointments: Appointment[];
  medicines: Medicine[];
  exercises: Exercise[];
  setProfile: (profile: PatientProfile) => void;
  addAppointment: (appointment: Appointment) => void;
  addMedicine: (medicine: Medicine) => void;
  addExercise: (exercise: Exercise) => void;
  toggleExercise: (id: string) => void;
}

export const useStore = create<Store>((set) => ({
  profile: null,
  appointments: [],
  medicines: [],
  exercises: [],
  setProfile: (profile) => set({ profile }),
  addAppointment: (appointment) =>
    set((state) => ({ appointments: [...state.appointments, appointment] })),
  addMedicine: (medicine) =>
    set((state) => ({ medicines: [...state.medicines, medicine] })),
  addExercise: (exercise) =>
    set((state) => ({ exercises: [...state.exercises, exercise] })),
  toggleExercise: (id) =>
    set((state) => ({
      exercises: state.exercises.map((exercise) =>
        exercise.id === id
          ? { ...exercise, completed: !exercise.completed }
          : exercise
      ),
    })),
}));